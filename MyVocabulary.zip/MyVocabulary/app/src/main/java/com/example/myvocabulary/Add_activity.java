package com.example.myvocabulary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Add_activity extends AppCompatActivity {

    TextView english_text, greek_text, hind_text;
    Button add_button;
    String english, greek, hind;
    Word word;
    DatabaseHelper databaseHelper = new DatabaseHelper(Add_activity.this);
    ArrayList<Word> words = new ArrayList<Word>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        init();
    }

    private void init(){
        setViews();
        setListeners();
        words = databaseHelper.readAll();
    }

    private void setViews(){
        english_text = findViewById(R.id.add_english);
        greek_text = findViewById(R.id.add_greek);
        hind_text = findViewById(R.id.add_hind);
        add_button = findViewById(R.id.add_add_button);
    }

    private void setListeners(){
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(check()){
                    add_Word();
                }
            }
        });
    }

    private void add_Word(){
        english = english_text.getText().toString();
        greek = greek_text.getText().toString();
        hind = hind_text.getText().toString();
        word = new Word(english, greek, hind, 0, 0);
        english_text.setText("");
        greek_text.setText("");
        hind_text.setText("");
        databaseHelper.add(word);
    }

    private boolean check(){
        for(Word word: words){
            if(word.getEnglish().equals(english_text.getText().toString())){
                Toast.makeText(Add_activity.this,"There is already this word", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

}