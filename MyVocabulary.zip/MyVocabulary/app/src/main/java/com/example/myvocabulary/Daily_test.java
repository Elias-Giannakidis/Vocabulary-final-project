package com.example.myvocabulary;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Daily_test extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView progressText, questionText, answerText, resultText, resultIconText;
    private Button enterButton;
    private final DatabaseHelper databaseHelper = new DatabaseHelper(Daily_test.this);
    private WordList allWords = new WordList();
    private int progress, testSize, position, completedWords;
    private final int MAX_TEST_SIZE = 7;
    private final Random random = new Random();
    private String answer, question;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_test);
    }

    @Override
    protected void onResume(){
        super.onResume();
        init();
    }

    private void init(){
        progress = 0;
        completedWords = 0;
        allWords.clear();
        findViews();
        makeTestList();
        setListeners();
    }

    private void findViews(){
        progressBar = findViewById(R.id.daily_progress_bar);
        enterButton = findViewById(R.id.daily_enter_button);
        questionText = findViewById(R.id.daily_tested_word);
        answerText = findViewById(R.id.daily_answer_text);
        resultText = findViewById(R.id.daily_result_text);
        resultIconText = findViewById(R.id.daily_resultIcon_text);
        progressText = findViewById(R.id.daily_progressText);
    }

    private void setListeners(){
        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!allWords.getTestList().isEmpty()) {
                    check();
                    changeWord();
                    progress = findProgress();
                    progressBar.setProgress(progress);
                    progressText.setText(String.valueOf(progress) + "/100");
                    getTest();
                }else{
                    Toast.makeText(Daily_test.this,"Start new test",Toast.LENGTH_SHORT).show();
                    init();
                    progress = 0;
                    progressBar.setProgress(progress);
                }
            }
        });
    }

    private void makeTestList(){
        allWords.updateList(databaseHelper.readAll());
        allWords.makeTest(MAX_TEST_SIZE, WordList.MIN_SCORE);
        testSize = allWords.getTestListSize();
        if(!allWords.getTestList().isEmpty()){
            position = random.nextInt(allWords.getTestList().size());
            getTest();
        }
        else{
            Toast.makeText(Daily_test.this,"There is no word for testng", Toast.LENGTH_SHORT).show();
        }
    }

    private void check(){
        answer = answerText.getText().toString();
        question = questionText.getText().toString();
        if(allWords.getTestList().get(position).check(question, answer)){
            resultIconText.setBackgroundColor(Color.GREEN);
            resultText.setText(allWords.getTestList().get(position).getHint());
            resultIconText.setText("OK");
        }else{
            resultText.setText("(" + questionText.getText().toString() + ") = (" + allWords.getTestList().get(position).getAnswer(questionText.getText().toString()) + ")");
            resultIconText.setBackgroundColor(Color.RED);
            resultIconText.setText("WRONG");
        }
    }

    private int findProgress(){
        int score = 0;
        if(!allWords.getTestList().isEmpty()) {
            for (Word word : allWords.getTestList()) {
                score += word.getEnglishScore();
                score += word.getGreekScore();
            }
            return 100*(score + 6*completedWords)/(6*testSize);
        }
        return 100;
    }

    private void changeWord(){
        if(allWords.getTestList().get(position).getEnglishScore() >= 3 && allWords.getTestList().get(position).getGreekScore() >=3){
            allWords.getTestList().get(position).increaseScore(5);
            allWords.updateWord(allWords.getTestList().get(position));
            allWords.getTestList().remove(position);
            completedWords++;
        }
        if(!allWords.getTestList().isEmpty()) {
            position = random.nextInt(allWords.getTestList().size());
        }else{
            databaseHelper.deleteAll();
            databaseHelper.updateAll(allWords);
            resultIconText.setText("BRAVO!");
            Toast.makeText(Daily_test.this, "The test is completed!!!", Toast.LENGTH_SHORT).show();
        }
    }

    private void getTest(){
        if(!allWords.getTestList().isEmpty()) {
            if (allWords.getTestList().get(position).getEnglishScore() >= 3 && allWords.getTestList().get(position).getGreekScore() < 3) {
                questionText.setText(allWords.getTestList().get(position).getGreek());
                answerText.setText("");
            } else if (allWords.getTestList().get(position).getEnglishScore() < 3 && allWords.getTestList().get(position).getGreekScore() >= 3) {
                questionText.setText(allWords.getTestList().get(position).getEnglish());
                answerText.setText("");
            } else if (allWords.getTestList().get(position).getEnglishScore() < 3 && allWords.getTestList().get(position).getGreekScore() < 3) {
                if (random.nextBoolean()) {
                    questionText.setText(allWords.getTestList().get(position).getEnglish());
                } else {
                    questionText.setText(allWords.getTestList().get(position).getGreek());
                }
                answerText.setText("");
            } else {
                Toast.makeText(Daily_test.this, "Something goes wrong", Toast.LENGTH_SHORT).show();
                questionText.setText("");
                answerText.setText("");
            }
        }else{
            questionText.setText("");
            answerText.setText("");
        }
    }

}