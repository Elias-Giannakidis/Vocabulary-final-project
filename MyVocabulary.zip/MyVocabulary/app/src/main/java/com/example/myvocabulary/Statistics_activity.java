package com.example.myvocabulary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Statistics_activity extends AppCompatActivity {

    private TextView txt_words, txt_new_words, txt_main_score, txt_max_score, txt_sentences, txt_views;
    private WordList wordList = new WordList();
    private final DatabaseHelper databaseHelper = new DatabaseHelper(Statistics_activity.this);
    private int words, new_words, main_score, max_score, sentences, views;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
    }

    @Override
    protected void onResume(){
        super.onResume();
        init();
    }

    private void init() {
        wordList.clear();
        wordList.updateList(databaseHelper.readAll());
        findViews();
        getStatistics();
        writeText();
    }

    private void writeText() {
        txt_words.setText("WORDS: " + String.valueOf(words));
        txt_new_words.setText("NEW WORDS: " + String.valueOf(new_words));
        txt_main_score.setText("MAIN SCORE: " + String.valueOf(main_score));
        txt_max_score.setText("MAX SCORE: " + String.valueOf(max_score));
        txt_sentences.setText("SENTENCES: " + String.valueOf(sentences));
        txt_views.setText("TOTAL VIEWS: " + String.valueOf(views));
    }

    private void getStatistics() {
        words = wordList.size();
        new_words = 0;
        main_score = 0;
        max_score = 0;
        sentences = 0;
        views = 0;
        for(Word word : wordList){
            main_score += word.getScore();
            views += word.getViews();
            if(word.getScore() == 0){
                new_words++;
            }
            if(word.getScore() > max_score){
                max_score = word.getScore();
            }
            if(!word.getHint().equals("There is no hint")){
                sentences++;
            }
        }
        if(wordList.size() > 0) {
            main_score = main_score / wordList.size();
        }

    }

    private void findViews() {
        txt_words = findViewById(R.id.statistics_words);
        txt_new_words = findViewById(R.id.statistics_new_words);
        txt_main_score = findViewById(R.id.statistics_main_score);
        txt_max_score = findViewById(R.id.statistics_max_score);
        txt_sentences = findViewById(R.id.statistics_sentences);
        txt_views = findViewById(R.id.statistics_views);
    }
}