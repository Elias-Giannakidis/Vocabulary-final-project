package com.example.myvocabulary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button daily_button, tests_button, vocabulary_button, add_button, statistics_button;
    TextView hind_text;
    Intent intent;
    Random random = new Random();
    DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this);
    ArrayList<Word> words = new ArrayList<Word>();
    Word word;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    @Override
    protected void onResume(){
        super.onResume();
        makeHind();
    }

    private void init() {
        findViews();
        setListeners();
        makeHind();
    }

    private void findViews(){
        daily_button = findViewById(R.id.home_daily_button);
        tests_button = findViewById(R.id.home_tests_button);
        vocabulary_button = findViewById(R.id.home_vocabulary_button);
        add_button = findViewById(R.id.home_add_button);
        statistics_button = findViewById(R.id.home_statistics_button);
        hind_text = findViewById(R.id.home_hind_text);
    }

    private void setListeners(){
        daily_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Daily_test.class);
                startActivity(intent);
            }
        });

        tests_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Tests_activity.class);
                startActivity(intent);
            }
        });

        vocabulary_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //intent = new Intent(MainActivity.this, Vocabulary_activity.class);
               // startActivity(intent);
                makeHind();
            }
        });

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Add_activity.class);
                startActivity(intent);
            }
        });

        statistics_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Statistics_activity.class);
                startActivity(intent);
            }
        });

    }

    private void makeHind(){
        words = databaseHelper.readAll();
        if(words.size() > 0){
            int i = random.nextInt(words.size());
            word = words.get(i);
            hind_text.setText(word.getHind());
        }
    }

}