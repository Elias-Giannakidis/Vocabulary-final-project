package com.example.myvocabulary;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Vocabulary_activity extends AppCompatActivity {

    TextView search, english, greek, hint, score, views;
    Button nextButton, previousButton, deleteAllButton, deleteButton, selectButton;
    ImageView searchImage;
    ArrayList<Word> words = new ArrayList<Word>();
    DatabaseHelper databaseHelper = new DatabaseHelper(Vocabulary_activity.this);
    private Handler mHadler = new Handler();
    int position = 0;
    int deleteAllCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocabulary);
        init();
    }

    private void init(){
        words = databaseHelper.readAll();
        findViews();
        read(position);
        setListeners();
    }

    private void findViews(){
        search = findViewById(R.id.vocabulary_search_text);
        english = findViewById(R.id.vocabulary_English_text);
        greek = findViewById(R.id.vocabulary_Greek_text);
        hint = findViewById(R.id.vocabulary_Hint_text);
        score = findViewById(R.id.vocabulary_Score_text);
        views = findViewById(R.id.vocabulary_Views_text);
        nextButton = findViewById(R.id.vocabulary_next_button);
        previousButton = findViewById(R.id.vocabulary_previous_button);
        deleteButton = findViewById(R.id.vocabulary_delete_button);
        selectButton = findViewById(R.id.vocabulary_select_button);
        deleteAllButton = findViewById(R.id.vocabulary_deleteAll_button);
        searchImage = findViewById(R.id.vocabulary_search_icon);
    }

    private void setListeners(){
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position++;
                read(position);
            }
        });

        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position--;
                read(position);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!words.isEmpty()) {
                    words.remove(position);
                    if (!words.isEmpty()) {
                        databaseHelper.deleteAll();
                        databaseHelper.updateAll(words);
                        read(position);
                    } else if (words.isEmpty()) {
                        databaseHelper.deleteAll();
                        english.setText("");
                        greek.setText("");
                        hint.setText("");
                        score.setText("");
                        views.setText("");
                    }
                }
            }
        });

        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!words.isEmpty()) {
                    WordList wordList = new WordList();
                    wordList.updateList(words);
                    Word word = new Word(english.getText().toString(), greek.getText().toString(), hint.getText().toString(), Integer.parseInt(score.getText().toString()), Integer.parseInt(views.getText().toString()));
                    words.get(position).setEnglish(english.getText().toString());
                    words.get(position).setGreek(greek.getText().toString());
                    words.get(position).setHint(hint.getText().toString());
                    words.get(position).setScore(Integer.parseInt(score.getText().toString()));
                    words.get(position).setViews(Integer.parseInt(views.getText().toString()));
                    databaseHelper.deleteAll();
                    databaseHelper.updateAll(words);
                }else{
                    Word word = new Word(english.getText().toString(), greek.getText().toString(), hint.getText().toString(), 0, 0);
                    databaseHelper.add(word);
                    words = databaseHelper.readAll();
                    read(position);
                }
            }
        });

        deleteAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(deleteAllCounter == 0){
                    Toast.makeText(Vocabulary_activity.this, "Press three times to delete all list", Toast.LENGTH_SHORT).show();
                    mHadler.postDelayed(restartDeleteCounter, 2500);
                }
                deleteAllCounter++;
                if(deleteAllCounter == 3){
                    databaseHelper.deleteAll();
                    words.clear();
                    position = 0;
                    english.setText("");
                    greek.setText("");
                    hint.setText("");
                    score.setText("");
                    views.setText("");
                }
            }
        });

        searchImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchWord();
            }
        });

    }

    private void read(int i){

        if(i < 0){
            i = 0;
            position = 0;
        }

        if(i > words.size() - 1){
            position = words.size() - 1;
            i = position;
        }

        if(!words.isEmpty()){
            Word word = words.get(i);
            english.setText(word.getEnglish());
            greek.setText(word.getGreek());
            hint.setText(word.getHint());
            score.setText(String.valueOf(word.getScore()));
            views.setText(String.valueOf(word.getViews()));
        }

    }

    private void searchWord(){
        String searchWord = search.getText().toString();
        search.setText("");
        for(int i = 0; i < words.size(); i++){
            if(words.get(i).getEnglish().equals(searchWord)|words.get(i).getGreek().equals(searchWord)){
                position = i;
                read(position);
            }
        }
    }

    private Runnable restartDeleteCounter = new Runnable() {
        @Override
        public void run() {
            deleteAllCounter = 0;
        }
    };

}