package com.example.myvocabulary;

public class Word {

    private String english, greek, hind;
    private int views, score;

    public Word(String english, String greek, String hind, int views, int score){
        this.english = english;
        this.greek = greek;
        this.hind = hind;
        this.views = views;
        this.score = score;
    }

    public String getEnglish(){
        return this.english;
    }

    public String getGreek(){
        return this.greek;
    }

    public String getHind(){
        return this.hind;
    }

    public int getViews(){
        return this.views;
    }

    public int getScore(){
        return this.score;
    }

    public void increaseViews(){
        this.views++;
    }

    public void increaseScore(){
        this.score++;
    }

    public void reset(){
        this.score = 0;
        this.views = 0;
    }

}
