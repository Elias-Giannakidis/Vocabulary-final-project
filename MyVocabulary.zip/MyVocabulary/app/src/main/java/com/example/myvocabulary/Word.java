package com.example.myvocabulary;

import java.util.Random;

public class Word {

    private String english, greek, hint;
    private int views, score;
    private Random random = new Random();
    private int englishScore, greekScore;

    public Word(String english, String greek, String hint, int views, int score){
        this.english = english;
        this.greek = greek;
        this.hint = hint;
        this.views = views;
        this.score = score;
        this.greekScore = 0;
        this.englishScore = 0;
        if(this.hint.equals("")){
            this.hint = "There is no hint";
        }
    }

    public String getEnglish(){
        return this.english;
    }

    public void setEnglish(String english){
        this.english =  english;
    }

    public String getGreek(){
        return this.greek;
    }

    public void setGreek(String greek){
        this.greek = greek;
    }

    public String getHint(){
        return this.hint;
    }

    public void setHint(String hint){
        this.hint = hint;
    }

    public int getViews(){
        return this.views;
    }

    public void setViews(int views){
        this.views = views;
    }

    public int getScore(){
        return this.score;
    }

    public void setScore(int score){
        this.score = score;
    }

    public void increaseViews(){
        this.views++;
    }

    public void increaseScore(int i){
        this.score += i;
    }

    public void reset(){
        this.score = 0;
        this.views = 0;
    }

    public int getEnglishScore(){
        return englishScore;
    }

    public int getGreekScore(){
        return greekScore;
    }

    public boolean check(String question, String answer){
        if(answer.equals(this.english)&&question.equals(this.greek)) {
            greekScore++;
            return true;
        }
        if(answer.equals(this.greek)&&question.equals(this.english)) {
            englishScore++;
            return true;
        }
        this.englishScore = 0;
        this.greekScore = 0;
        return false;
    }

    public void refreshTestScores(){
        this.englishScore = 0;
        this.greekScore = 0;
    }

    public String getAnswer(String question){
        if(question.equals(this.english))
            return this.greek;
        if(question.equals(this.greek))
            return this.english;
        return "Something goes wrong";
    }

}
