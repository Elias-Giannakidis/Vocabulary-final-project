package com.example.myvocabulary;

import java.util.ArrayList;

public class WordList extends ArrayList<Word> {

    private ArrayList<Word> testList = new ArrayList<Word>();
    public static final int MIN_SCORE = 0;
    public static final int MIN_VIEWS = 1;
    public static final int RANDOM = 2;
    private int test_size = 0;

    public ArrayList<Word> getTestList(){
        return testList;
    }

    public int getTestListSize(){
        return this.testList.size();
    }

    public void makeTest(int test_size, int test_type){
        this.test_size = test_size;
        if(test_type == MIN_SCORE){
            this.testList.clear();
            for(int i = 0; i < this.size() ; i++){
                Word movedWord = this.get(i);
                if(this.testList.size() < test_size) {
                    this.testList.add(movedWord);
                }else{
                    for(int j = 0; j < test_size; j++){
                        if(movedWord.getScore() < this.testList.get(j).getScore()){
                            this.testList.add(movedWord);
                            movedWord = this.testList.get(j);
                            this.testList.remove(j);
                        }else if (movedWord.getScore() == this.testList.get(j).getScore()){
                            if(movedWord.getViews() < this.testList.get(j).getViews()){
                                this.testList.add(movedWord);
                                movedWord = this.testList.get(j);
                                this.testList.remove(j);
                            }
                        }
                    }
                }
            }
        }else if(test_type == MIN_VIEWS){
            testList.clear();
            for(Word movedWord : this){
                if(testList.size() < test_size)
                    testList.add(movedWord);
                else{
                    for(int j = 0; j < test_size; j++){
                        if(movedWord.getViews() < testList.get(j).getViews()){
                            testList.add(movedWord);
                            movedWord = testList.get(j);
                            testList.remove(j);
                        }else if (movedWord.getViews() == testList.get(j).getViews()){
                            if(movedWord.getScore() < testList.get(j).getScore()){
                                testList.add(movedWord);
                                movedWord = testList.get(j);
                                testList.remove(j);
                            }
                        }
                    }
                }
            }
        }else if(test_type == RANDOM){
            testList.clear();
        }
        if(!this.testList.isEmpty()){
            for(int i = 0; i < this.testList.size(); i++){
                this.testList.get(i).increaseViews();
            }
        }
    }

    public void updateList(ArrayList<Word> list){
        this.clear();
        for(Word moved : list) {
            for (Word word : this) {
                if(word.getEnglish().equals(moved.getEnglish())){
                    this.remove(word);
                }
            }
            this.add(moved);
        }
    }

    public boolean updateWord(Word word){
        for(int i = 0; i < this.size(); i++){
            if(word.getEnglish().equals(this.get(i).getEnglish())){
                this.remove(i);
                this.add(word);
                return true;
            }
        }
        this.add(word);
        return false;
    }

    public boolean included(Word newWord){
        for(Word word : this){
            if(word.getEnglish().equals(newWord.getEnglish())|word.getGreek().equals(newWord.getGreek())){
                return true;
            }else{
                return false;
            }
        }
        return true;
    }
}
